/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { HomeSection } from './components/HomeSection';
import { AboutSection } from './components/AboutSection';
import { SubsidiariesSection } from './components/SubsidiariesSection';
import { InvestorSection } from './components/InvestorSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { PartnerPortalModal } from './components/PartnerPortalModal';
import { ArthavestMetricsModal } from './components/ArthavestMetricsModal';
import { ShareholderReportModal } from './components/ShareholderReportModal';

export default function App() {
  const [currentSection, setCurrentSection] = useState<string>('home');
  const [activeSubsidiary, setActiveSubsidiary] = useState<string>('arthavest');

  // Modals
  const [isPortalModalOpen, setIsPortalModalOpen] = useState(false);
  const [isArthavestModalOpen, setIsArthavestModalOpen] = useState(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);

  const handleNavigate = (sectionId: string) => {
    setCurrentSection(sectionId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectSubsidiary = (subId: string) => {
    setActiveSubsidiary(subId);
  };

  return (
    <div className="min-h-screen bg-[#02050d] text-[#e2e8f0] selection:bg-[#E5B834] selection:text-black flex flex-col">
      {/* Fixed Navigation */}
      <Navbar
        currentSection={currentSection}
        onNavigate={handleNavigate}
        onOpenPortal={() => setIsPortalModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="pt-20 flex-1">
        {currentSection === 'home' && (
          <HomeSection
            onNavigate={handleNavigate}
            onSelectSubsidiary={handleSelectSubsidiary}
          />
        )}

        {currentSection === 'about' && <AboutSection />}

        {currentSection === 'portfolio' && (
          <SubsidiariesSection
            activeSubsidiary={activeSubsidiary}
            onSelectSubsidiary={handleSelectSubsidiary}
            onOpenArthavestModal={() => setIsArthavestModalOpen(true)}
          />
        )}

        {currentSection === 'investor' && (
          <InvestorSection
            onOpenReportModal={() => setIsReportModalOpen(true)}
            onOpenPortalModal={() => setIsPortalModalOpen(true)}
          />
        )}

        {currentSection === 'contact' && <ContactSection />}
      </main>

      {/* Institutional Footer */}
      <Footer
        onNavigate={handleNavigate}
        onSelectSubsidiary={handleSelectSubsidiary}
        onOpenPortal={() => setIsPortalModalOpen(true)}
      />

      {/* Modals */}
      <PartnerPortalModal
        isOpen={isPortalModalOpen}
        onClose={() => setIsPortalModalOpen(false)}
      />

      <ArthavestMetricsModal
        isOpen={isArthavestModalOpen}
        onClose={() => setIsArthavestModalOpen(false)}
      />

      <ShareholderReportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
      />
    </div>
  );
}
