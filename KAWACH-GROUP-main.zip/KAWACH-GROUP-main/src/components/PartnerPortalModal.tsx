import React, { useState } from 'react';
import { X, Lock, ShieldCheck, UserCheck, ArrowRight, LogOut, CheckCircle2, Vote } from 'lucide-react';

interface PartnerPortalModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PartnerPortalModal: React.FC<PartnerPortalModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [voteCasted, setVoteCasted] = useState<Record<number, string>>({});

  if (!isOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsAuthenticated(true);
  };

  const handleDemoFill = () => {
    setEmail('mahendra.dahal@kawachgroup.com');
    setPassword('••••••••••••');
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setEmail('');
    setPassword('');
  };

  const castVote = (resolutionId: number, decision: string) => {
    setVoteCasted((prev) => ({ ...prev, [resolutionId]: decision }));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="glass-card max-w-lg w-full p-6 sm:p-8 rounded-3xl relative border border-[#E5B834]/35 shadow-2xl max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-gray-400 hover:text-white text-xl p-1 rounded-lg hover:bg-white/10 transition-colors"
          aria-label="Close portal modal"
        >
          <X className="w-5 h-5" />
        </button>

        {!isAuthenticated ? (
          <div>
            <div className="text-center mb-6">
              <div className="w-12 h-12 rounded-xl bg-[#E5B834]/10 border border-[#E5B834]/30 flex items-center justify-center text-[#F6D061] text-xl mx-auto mb-3">
                <Lock className="w-6 h-6 stroke-[2]" />
              </div>
              <h3 className="heading-font text-2xl font-bold text-white">
                KAWACH Partner Portal
              </h3>
              <p className="text-xs text-gray-400 mt-1">
                Authorized Shareholder & Syndicate Authentication
              </p>
            </div>

            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-xs uppercase text-gray-400 font-bold mb-1.5">
                  Partner ID / Email
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-[#02050d] border border-[#E5B834]/20 text-white text-sm focus:outline-none focus:border-[#E5B834] transition-colors"
                  placeholder="partner@arthavest.com"
                />
              </div>

              <div>
                <label className="block text-xs uppercase text-gray-400 font-bold mb-1.5">
                  Security Key / Password
                </label>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-[#02050d] border border-[#E5B834]/20 text-white text-sm focus:outline-none focus:border-[#E5B834] transition-colors"
                  placeholder="••••••••••••"
                />
              </div>

              <div className="pt-2 space-y-2">
                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl text-xs font-bold uppercase tracking-wider text-[#02050d] bg-gradient-to-r from-[#F6D061] via-[#E5B834] to-[#C89B1D] hover:shadow-lg hover:shadow-[#E5B834]/25 transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
                >
                  <span>Authenticate Session</span>
                  <ArrowRight className="w-4 h-4 stroke-[2.4]" />
                </button>

                <button
                  type="button"
                  onClick={handleDemoFill}
                  className="w-full py-2.5 rounded-xl text-xs font-medium text-[#F6D061] bg-[#E5B834]/10 hover:bg-[#E5B834]/15 border border-[#E5B834]/25 transition-colors text-center"
                >
                  Quick Demo Access (Executive Board)
                </button>
              </div>
            </form>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#E5B834]/15 border border-[#E5B834]/30 flex items-center justify-center text-[#F6D061]">
                  <UserCheck className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="heading-font text-lg font-bold text-white leading-none">
                    Mahendra Dahal
                  </h4>
                  <span className="text-[10px] uppercase text-[#F6D061] font-semibold tracking-wider">
                    Founding Shareholder · Seat #01
                  </span>
                </div>
              </div>
              <button
                onClick={handleLogout}
                className="text-xs text-gray-400 hover:text-white flex items-center gap-1 p-1.5 rounded-lg hover:bg-white/5"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Exit</span>
              </button>
            </div>

            {/* Balances */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-4 rounded-xl bg-[#02050d] border border-white/10">
                <div className="text-[11px] text-gray-400">Equity Shareholding</div>
                <div className="text-xl font-bold text-white mt-1 mono-font">10.0%</div>
                <div className="text-[10px] text-[#F6D061] mt-0.5">Founding Quorum</div>
              </div>
              <div className="p-4 rounded-xl bg-[#02050d] border border-white/10">
                <div className="text-[11px] text-gray-400">Capital Ledger</div>
                <div className="text-xl font-bold text-[#F6D061] mt-1 mono-font tabular-nums">
                  NPR 12.5M
                </div>
                <div className="text-[10px] text-emerald-400 mt-0.5">+18.4% FY2082 Gain</div>
              </div>
            </div>

            {/* Active Governance Resolutions for Voting */}
            <div>
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-gray-300 mb-3">
                <Vote className="w-4 h-4 text-[#E5B834]" />
                <span>Active Board Resolutions</span>
              </div>
              <div className="space-y-3">
                <div className="p-3.5 rounded-xl bg-[#02050d]/80 border border-white/10 text-xs">
                  <div className="font-semibold text-white mb-1">
                    Res #2082-04: Authorize Additional Broker TMS Clearing Limit
                  </div>
                  <p className="text-gray-400 text-[11px] mb-2.5">
                    Proposal to raise institutional Demat order placement threshold to NPR 50M.
                  </p>
                  {voteCasted[1] ? (
                    <div className="text-emerald-400 font-semibold flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Vote Recorded: {voteCasted[1]}</span>
                    </div>
                  ) : (
                    <div className="flex gap-2">
                      <button
                        onClick={() => castVote(1, 'Approved')}
                        className="px-3 py-1 rounded-md bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 font-semibold text-[11px]"
                      >
                        Approve (Yes)
                      </button>
                      <button
                        onClick={() => castVote(1, 'Rejected')}
                        className="px-3 py-1 rounded-md bg-red-500/20 text-red-300 hover:bg-red-500/30 font-semibold text-[11px]"
                      >
                        Reject
                      </button>
                    </div>
                  )}
                </div>

                <div className="p-3.5 rounded-xl bg-[#02050d]/80 border border-white/10 text-xs">
                  <div className="font-semibold text-white mb-1">
                    Res #2082-05: Kawach Foods Spice Processing Unit Phase 2
                  </div>
                  <p className="text-gray-400 text-[11px] mb-2.5">
                    Capital allocation of NPR 8.5M for automated packaging equipment acquisition.
                  </p>
                  {voteCasted[2] ? (
                    <div className="text-emerald-400 font-semibold flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Vote Recorded: {voteCasted[2]}</span>
                    </div>
                  ) : (
                    <div className="flex gap-2">
                      <button
                        onClick={() => castVote(2, 'Approved')}
                        className="px-3 py-1 rounded-md bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 font-semibold text-[11px]"
                      >
                        Approve (Yes)
                      </button>
                      <button
                        onClick={() => castVote(2, 'Rejected')}
                        className="px-3 py-1 rounded-md bg-red-500/20 text-red-300 hover:bg-red-500/30 font-semibold text-[11px]"
                      >
                        Reject
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-full py-3 rounded-xl text-xs font-bold uppercase tracking-wider text-[#02050d] bg-[#E5B834] hover:bg-[#F6D061] transition-colors"
            >
              Close Portal View
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
