import React from 'react';
import {
  TrendingUp,
  Coins,
  Factory,
  Cpu,
  ArrowUpRight,
  Shield,
  Layers,
  CheckCircle2,
  ExternalLink,
  Code2,
  Lock,
  Boxes,
  Activity,
  Award,
  ShieldCheck
} from 'lucide-react';

interface SubsidiariesSectionProps {
  activeSubsidiary: string;
  onSelectSubsidiary: (subId: string) => void;
  onOpenArthavestModal: () => void;
}

export const SubsidiariesSection: React.FC<SubsidiariesSectionProps> = ({
  activeSubsidiary,
  onSelectSubsidiary,
  onOpenArthavestModal,
}) => {
  const tabs = [
    { id: 'arthavest', label: 'Arthavest Investment', icon: TrendingUp },
    { id: 'rwa', label: 'Kawach RWA & Smart Contracts', icon: Coins },
    { id: 'fmcg', label: 'FMCG & Spice Manufacturing', icon: Factory },
    { id: 'tech', label: 'FinTech & Analytics', icon: Cpu },
  ];

  return (
    <section id="sec-portfolio" className="py-20 border-t border-[#E5B834]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="text-xs uppercase tracking-[0.25em] text-[#F6D061] font-semibold mb-3">
            Group Entities
          </div>
          <h2 className="heading-font text-3xl sm:text-5xl font-bold text-white mb-6">
            Subsidiary Ecosystem
          </h2>
          <p className="text-gray-300 font-light text-base leading-relaxed">
            Select an autonomous company vertical below to view detailed operational profiles, key performance indices, governance protocols, and technical architecture.
          </p>
        </div>

        {/* Subsidiary Selector Segmented Control / Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-2.5 mb-12">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeSubsidiary === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onSelectSubsidiary(tab.id)}
                className={`px-5 py-3 rounded-xl text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-2 cursor-pointer ${
                  isActive
                    ? 'bg-[#E5B834] text-[#02050d] shadow-lg shadow-[#E5B834]/25 scale-100 font-extrabold'
                    : 'bg-[#050a17] text-gray-300 hover:text-white border border-[#E5B834]/20 hover:border-[#E5B834]/40'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-[#02050d]' : 'text-[#F6D061]'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab 1: ARTHAVEST INVESTMENT COMPANY */}
        {activeSubsidiary === 'arthavest' && (
          <div className="glass-card p-8 sm:p-12 rounded-3xl border border-[#E5B834]/30 space-y-8 animate-in fade-in duration-300">
            <div className="flex flex-col lg:flex-row items-start justify-between gap-6 pb-6 border-b border-white/10">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs font-bold uppercase mb-4">
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  <span>Operational & Registered Entity</span>
                </div>
                <h3 className="heading-font text-2xl sm:text-4xl font-bold text-white mb-2">
                  Arthavest Investment Company Pvt. Ltd.
                </h3>
                <p className="text-[#F6D061] text-xs uppercase tracking-widest font-semibold">
                  Flagship Equity & Market Investment Engine
                </p>
              </div>

              <div className="flex flex-wrap gap-3">
                <button
                  onClick={onOpenArthavestModal}
                  className="px-5 py-3 rounded-xl text-xs font-bold uppercase tracking-wider text-white border border-[#E5B834]/50 hover:bg-[#E5B834]/15 transition-all flex items-center gap-2 cursor-pointer active:scale-95 shadow-md shadow-black/40"
                >
                  <span>View Dashboard Metrics</span>
                  <ExternalLink className="w-3.5 h-3.5 text-[#F6D061]" />
                </button>
              </div>
            </div>

            <p className="text-gray-300 text-base leading-relaxed">
              Arthavest Investment Company is KAWACH Group’s core financial powerhouse. Registered under the Office of the Company Registrar (OCR Nepal, Falgun 2082), Arthavest executes systematic multi-partner capital pooling, quantitative NEPSE equity investments, gold (XAU/USD) strategies, and proprietary risk-managed portfolio allocations.
            </p>

            {/* Highlights Grid */}
            <div className="grid sm:grid-cols-3 gap-6">
              <div className="p-6 rounded-2xl bg-[#02050d]/70 border border-[#E5B834]/20 hover:border-[#E5B834]/40 transition-colors">
                <div className="w-10 h-10 rounded-xl bg-[#E5B834]/10 flex items-center justify-center text-[#F6D061] mb-4">
                  <Award className="w-5 h-5" />
                </div>
                <div className="text-white font-bold text-lg mb-1">
                  10-Partner Synergy
                </div>
                <p className="text-gray-400 text-xs leading-relaxed">
                  Pooled equity investment framework with structured corporate charter governance, equal shareholder transparency, and dividend accrual clauses.
                </p>
              </div>

              <div className="p-6 rounded-2xl bg-[#02050d]/70 border border-[#E5B834]/20 hover:border-[#E5B834]/40 transition-colors">
                <div className="w-10 h-10 rounded-xl bg-[#E5B834]/10 flex items-center justify-center text-[#F6D061] mb-4">
                  <Activity className="w-5 h-5" />
                </div>
                <div className="text-white font-bold text-lg mb-1">
                  Quantitative Screening
                </div>
                <p className="text-gray-400 text-xs leading-relaxed">
                  Monte Carlo simulations, algorithmic VaR risk ceilings, and systematic momentum-growth rebalancing for NEPSE equities & Global Commodities.
                </p>
              </div>

              <div className="p-6 rounded-2xl bg-[#02050d]/70 border border-[#E5B834]/20 hover:border-[#E5B834]/40 transition-colors">
                <div className="w-10 h-10 rounded-xl bg-[#E5B834]/10 flex items-center justify-center text-[#F6D061] mb-4">
                  <Shield className="w-5 h-5" />
                </div>
                <div className="text-white font-bold text-lg mb-1">
                  Brokerage & TMS Ready
                </div>
                <p className="text-gray-400 text-xs leading-relaxed">
                  Full institutional Demat accounts, specialized MeroShare integration, corporate bank clearing, and designated broker TMS trade authorization.
                </p>
              </div>
            </div>

            {/* Strategy Snapshot Banner */}
            <div className="glass-card-subtle p-6 rounded-2xl border border-white/10 flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-[#E5B834]/15 flex items-center justify-center text-[#F6D061] shrink-0">
                  <TrendingUp className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-white font-bold text-sm">
                    Current Execution Target: Q1 2026 – Q4 2026 Strategy Run
                  </h4>
                  <p className="text-xs text-gray-400">
                    Allocating across NEPSE Commercial Banks, Hydropower, Microfinance, and Precious Metals Hedging.
                  </p>
                </div>
              </div>
              <button
                onClick={onOpenArthavestModal}
                className="px-4 py-2 rounded-lg bg-[#E5B834]/20 text-[#F6D061] hover:bg-[#E5B834]/30 text-xs font-semibold whitespace-nowrap transition-colors"
              >
                Inspect Portfolio Ratios
              </button>
            </div>
          </div>
        )}

        {/* Tab 2: KAWACH RWA SMART CONTRACTS */}
        {activeSubsidiary === 'rwa' && (
          <div className="glass-card p-8 sm:p-12 rounded-3xl border border-purple-500/30 space-y-8 animate-in fade-in duration-300">
            <div className="flex flex-col lg:flex-row items-start justify-between gap-6 pb-6 border-b border-white/10">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/15 border border-purple-500/30 text-purple-300 text-xs font-bold uppercase mb-4">
                  <Code2 className="w-3.5 h-3.5 text-purple-400" />
                  <span>Advanced Architecture Phase</span>
                </div>
                <h3 className="heading-font text-2xl sm:text-4xl font-bold text-white mb-2">
                  Kawach ($KWC) RWA Tokenization
                </h3>
                <p className="text-[#F6D061] text-xs uppercase tracking-widest font-semibold">
                  Institutional Real World Asset Ethereum Smart Contract
                </p>
              </div>

              <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-xs mono-font text-gray-300">
                <span className="text-purple-400 font-semibold">ERC-3643</span>
                <span>/</span>
                <span className="text-[#F6D061] font-semibold">ERC-4626</span>
              </div>
            </div>

            <p className="text-gray-300 text-base leading-relaxed">
              Engineered for high-value commercial real estate tokenization and institutional asset-backed liquidity. Kawach ($KWC) integrates multi-signature corporate governance, zero-knowledge self-recovery protocols, and automated anti-exploit behavioral defense mechanisms directly into the Ethereum blockchain.
            </p>

            <div className="grid sm:grid-cols-3 gap-6">
              <div className="p-6 rounded-2xl bg-[#02050d]/70 border border-purple-500/20 hover:border-purple-500/40 transition-colors">
                <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center text-purple-400 mb-4">
                  <Lock className="w-5 h-5" />
                </div>
                <div className="text-white font-bold text-lg mb-1">
                  Multi-Sig Vault
                </div>
                <p className="text-gray-400 text-xs leading-relaxed">
                  Multi-partner quorum execution (7/10 multisig threshold) for capital allocation, treasury unlock, and asset lockup protocols.
                </p>
              </div>

              <div className="p-6 rounded-2xl bg-[#02050d]/70 border border-purple-500/20 hover:border-purple-500/40 transition-colors">
                <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center text-purple-400 mb-4">
                  <Shield className="w-5 h-5" />
                </div>
                <div className="text-white font-bold text-lg mb-1">
                  ZK-Self Recovery
                </div>
                <p className="text-gray-400 text-xs leading-relaxed">
                  Zero-knowledge proof-based emergency key restoration protocol protecting against private key loss or corporate executive transitions.
                </p>
              </div>

              <div className="p-6 rounded-2xl bg-[#02050d]/70 border border-purple-500/20 hover:border-purple-500/40 transition-colors">
                <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center text-purple-400 mb-4">
                  <Boxes className="w-5 h-5" />
                </div>
                <div className="text-white font-bold text-lg mb-1">
                  Fractional Real Estate
                </div>
                <p className="text-gray-400 text-xs leading-relaxed">
                  On-chain yield distribution derived directly from prime commercial lease revenues, with automated monthly dividend streaming.
                </p>
              </div>
            </div>

            {/* Smart Contract Technical Spec Preview */}
            <div className="p-6 rounded-2xl bg-[#02050d] border border-purple-500/30 text-xs mono-font">
              <div className="flex items-center justify-between text-gray-400 pb-3 border-b border-white/10 mb-3">
                <span className="text-[#F6D061] font-semibold">Contract: KawachTokenVault.sol</span>
                <span>Solidity v0.8.24 · OpenZeppelin v5</span>
              </div>
              <div className="text-gray-300 space-y-1">
                <p className="text-purple-300">// Verified Architectural Invariants</p>
                <p>uint256 public constant QUORUM_THRESHOLD = 70; // 70% Partner Consensus</p>
                <p>bool public immutable ZK_EMERGENCY_RECOVERY_ENABLED = true;</p>
                <p>mapping(address =&gt; ComplianceBadge) internal verifiedStakeholders;</p>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: FMCG & SPICE MANUFACTURING */}
        {activeSubsidiary === 'fmcg' && (
          <div className="glass-card p-8 sm:p-12 rounded-3xl border border-amber-500/30 space-y-8 animate-in fade-in duration-300">
            <div className="flex flex-col lg:flex-row items-start justify-between gap-6 pb-6 border-b border-white/10">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold uppercase mb-4">
                  <Factory className="w-3.5 h-3.5 text-amber-400" />
                  <span>Market Entry & Setup Phase</span>
                </div>
                <h3 className="heading-font text-2xl sm:text-4xl font-bold text-white mb-2">
                  Kawach Foods & FMCG Manufacturing
                </h3>
                <p className="text-[#F6D061] text-xs uppercase tracking-widest font-semibold">
                  Premium Spice Processing & FMCG Supply Chain
                </p>
              </div>

              <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-xs text-gray-300">
                <span className="text-amber-400 font-semibold">Industrial Plant 1</span>
                <span>·</span>
                <span>Kathmandu Valley Hub</span>
              </div>
            </div>

            <p className="text-gray-300 text-base leading-relaxed">
              Entering Nepal&apos;s high-demand FMCG sector, Kawach Foods establishes modern spice processing, automated packaging, and domestic distribution channels. Leveraging organic local sourcing, stringent hygiene protocols, and high-efficiency manufacturing standards.
            </p>

            <div className="grid sm:grid-cols-3 gap-6">
              <div className="p-6 rounded-2xl bg-[#02050d]/70 border border-amber-500/20 hover:border-amber-500/40 transition-colors">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-400 mb-4">
                  <Cpu className="w-5 h-5" />
                </div>
                <div className="text-white font-bold text-lg mb-1">
                  State-of-the-Art Processing
                </div>
                <p className="text-gray-400 text-xs leading-relaxed">
                  Hygienic cold-grinding technology preserving essential aromatic oils and flavor profiles without thermal degradation.
                </p>
              </div>

              <div className="p-6 rounded-2xl bg-[#02050d]/70 border border-amber-500/20 hover:border-amber-500/40 transition-colors">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-400 mb-4">
                  <Layers className="w-5 h-5" />
                </div>
                <div className="text-white font-bold text-lg mb-1">
                  Nationwide Distribution
                </div>
                <p className="text-gray-400 text-xs leading-relaxed">
                  Robust retail and wholesale FMCG network setup throughout all 7 provinces of Nepal, reaching tier-1 and tier-2 grocers.
                </p>
              </div>

              <div className="p-6 rounded-2xl bg-[#02050d]/70 border border-amber-500/20 hover:border-amber-500/40 transition-colors">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-400 mb-4">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div className="text-white font-bold text-lg mb-1">
                  Agri-Sourcing Network
                </div>
                <p className="text-gray-400 text-xs leading-relaxed">
                  Direct contracts with domestic agricultural cooperatives ensuring pesticide testing, fair farmgate pricing, and traceability.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Tab 4: FINTECH & ANALYTICS */}
        {activeSubsidiary === 'tech' && (
          <div className="glass-card p-8 sm:p-12 rounded-3xl border border-blue-500/30 space-y-8 animate-in fade-in duration-300">
            <div className="flex flex-col lg:flex-row items-start justify-between gap-6 pb-6 border-b border-white/10">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/15 border border-blue-500/30 text-blue-300 text-xs font-bold uppercase mb-4">
                  <Cpu className="w-3.5 h-3.5 text-blue-400" />
                  <span>In-House R&D</span>
                </div>
                <h3 className="heading-font text-2xl sm:text-4xl font-bold text-white mb-2">
                  Arthavest P2P & Market Tech Engine
                </h3>
                <p className="text-[#F6D061] text-xs uppercase tracking-widest font-semibold">
                  Quantitative Screening & Institutional Risk Platforms
                </p>
              </div>

              <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-xs text-gray-300">
                <span className="text-blue-400 font-semibold">FastAPI 3.12</span>
                <span>·</span>
                <span>Python Quantitative Core</span>
              </div>
            </div>

            <p className="text-gray-300 text-base leading-relaxed">
              Our proprietary tech stack powering internal market intelligence. Arthavest Tech builds automated FastAPI quantitative screening tools, portfolio dashboards, and is pioneering the Arthavest P2P peer-to-peer micro-lending framework.
            </p>

            <div className="grid sm:grid-cols-3 gap-6">
              <div className="p-6 rounded-2xl bg-[#02050d]/70 border border-blue-500/20 hover:border-blue-500/40 transition-colors">
                <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-400 mb-4">
                  <Activity className="w-5 h-5" />
                </div>
                <div className="text-white font-bold text-lg mb-1">
                  FastAPI Risk Engine
                </div>
                <p className="text-gray-400 text-xs leading-relaxed">
                  High-speed real-time technical & quantitative market data processing pipeline digesting live price ticks and order books.
                </p>
              </div>

              <div className="p-6 rounded-2xl bg-[#02050d]/70 border border-blue-500/20 hover:border-blue-500/40 transition-colors">
                <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-400 mb-4">
                  <Layers className="w-5 h-5" />
                </div>
                <div className="text-white font-bold text-lg mb-1">
                  Arthavest P2P Platform
                </div>
                <p className="text-gray-400 text-xs leading-relaxed">
                  Automated credit scoring algorithm, escrow smart contract locking, and peer-to-peer liquidity deployment model.
                </p>
              </div>

              <div className="p-6 rounded-2xl bg-[#02050d]/70 border border-blue-500/20 hover:border-blue-500/40 transition-colors">
                <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-400 mb-4">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div className="text-white font-bold text-lg mb-1">
                  Aladdin-Style Architecture
                </div>
                <p className="text-gray-400 text-xs leading-relaxed">
                  Inspired by BlackRock Aladdin risk modeling architecture, enforcing portfolio stress-testing under market shocks.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
