import React from 'react';
import { ArrowUpRight, TrendingUp, ShieldCheck, Building2, Coins, Factory, Cpu } from 'lucide-react';
import { HeroCanvas } from './HeroCanvas';

interface HomeSectionProps {
  onNavigate: (sectionId: string) => void;
  onSelectSubsidiary: (subId: string) => void;
}

export const HomeSection: React.FC<HomeSectionProps> = ({
  onNavigate,
  onSelectSubsidiary,
}) => {
  const verticals = [
    {
      id: 'arthavest',
      name: 'Arthavest Investment Co.',
      tag: 'Flagship Equity Fund',
      icon: TrendingUp,
      desc: 'OCR-registered institutional pooling, quantitative NEPSE trading & gold commodities hedge.',
    },
    {
      id: 'rwa',
      name: 'Kawach RWA ($KWC)',
      tag: 'Smart Contract Vault',
      icon: Coins,
      desc: 'Tokenized commercial real estate, multi-signature corporate quorum, and ZK-recovery safety.',
    },
    {
      id: 'fmcg',
      name: 'Kawach Foods & FMCG',
      tag: 'Industrial Manufacturing',
      icon: Factory,
      desc: 'Modern hygienic spice processing, nationwide distribution channels, and origin agri-sourcing.',
    },
    {
      id: 'tech',
      name: 'Arthavest P2P Tech',
      tag: 'Quantitative Analytics',
      icon: Cpu,
      desc: 'FastAPI market intelligence engines, algorithmic VaR models, and peer-to-peer liquidity.',
    },
  ];

  return (
    <section id="sec-home" className="relative min-h-[92vh] flex flex-col justify-center hero-bg overflow-hidden py-16 lg:py-24">
      {/* Interactive Kinetic Filament Canvas */}
      <HeroCanvas />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center my-auto">
        {/* Editorial Subtitle Kicker */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#E5B834]/10 border border-[#E5B834]/30 text-[#F6D061] text-xs tracking-widest uppercase font-semibold mb-8">
          <ShieldCheck className="w-3.5 h-3.5 text-[#E5B834]" />
          <span>Strategic Multi-Industry Holdings</span>
        </div>

        {/* Main Headline */}
        <h1
          className="heading-font text-4xl sm:text-6xl lg:text-7xl font-black text-white leading-[1.12] mb-6 max-w-5xl mx-auto"
          style={{ textWrap: 'balance' }}
        >
          ENGINEERING CAPITAL,<br />
          <span className="gold-gradient-text">SHAPING DIVERSIFIED ENTERPRISE</span>
        </h1>

        {/* Subtitle */}
        <p className="max-w-3xl mx-auto text-base sm:text-lg text-gray-300 mb-10 font-light leading-relaxed">
          KAWACH GROUP stands as an institutional apex entity steering market dominance, financial engineering, high-growth capital investments, real-world asset innovation, and industrial manufacturing ventures.
        </p>

        {/* Hero CTAs */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
          <button
            onClick={() => onNavigate('portfolio')}
            className="w-full sm:w-auto px-8 py-4 rounded-xl text-xs font-bold uppercase tracking-wider text-[#02050d] bg-gradient-to-r from-[#F6D061] via-[#E5B834] to-[#C89B1D] hover:shadow-lg hover:shadow-[#E5B834]/25 transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
          >
            <span>Explore Group Subsidiaries</span>
            <ArrowUpRight className="w-4 h-4 stroke-[2.4]" />
          </button>
          <button
            onClick={() => onNavigate('about')}
            className="w-full sm:w-auto px-8 py-4 rounded-xl text-xs font-bold uppercase tracking-wider text-white border border-[#E5B834]/40 hover:bg-[#E5B834]/10 transition-all cursor-pointer active:scale-95"
          >
            Corporate Structure
          </button>
        </div>

        {/* Key Metrics Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-5xl mx-auto mb-16">
          <div className="glass-card p-6 rounded-2xl text-center">
            <div className="heading-font text-3xl lg:text-4xl font-extrabold text-[#F6D061] mb-1 mono-font tabular-nums">
              $50M+
            </div>
            <div className="text-xs uppercase text-gray-400 tracking-wider">
              AUM & Target Assets
            </div>
          </div>
          <div className="glass-card p-6 rounded-2xl text-center">
            <div className="heading-font text-3xl lg:text-4xl font-extrabold text-[#F6D061] mb-1 mono-font tabular-nums">
              4+
            </div>
            <div className="text-xs uppercase text-gray-400 tracking-wider">
              Strategic Business Verticals
            </div>
          </div>
          <div className="glass-card p-6 rounded-2xl text-center">
            <div className="heading-font text-3xl lg:text-4xl font-extrabold text-[#F6D061] mb-1">
              Institutional
            </div>
            <div className="text-xs uppercase text-gray-400 tracking-wider">
              Risk Architecture
            </div>
          </div>
          <div className="glass-card p-6 rounded-2xl text-center">
            <div className="heading-font text-3xl lg:text-4xl font-extrabold text-[#F6D061] mb-1">
              Multi-Asset
            </div>
            <div className="text-xs uppercase text-gray-400 tracking-wider">
              Growth Framework
            </div>
          </div>
        </div>

        {/* Verticals Quick Overview Strip */}
        <div className="max-w-6xl mx-auto text-left">
          <div className="flex items-center justify-between mb-4 border-b border-[#E5B834]/15 pb-2">
            <span className="text-xs uppercase tracking-widest text-gray-400 font-semibold">
              Operating Verticals
            </span>
            <button
              onClick={() => onNavigate('portfolio')}
              className="text-xs text-[#F6D061] hover:underline flex items-center gap-1"
            >
              <span>View detailed dossier</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {verticals.map((v) => {
              const IconComp = v.icon;
              return (
                <button
                  key={v.id}
                  onClick={() => {
                    onSelectSubsidiary(v.id);
                    onNavigate('portfolio');
                  }}
                  className="glass-card p-5 rounded-xl text-left hover:border-[#E5B834]/50 transition-all group block cursor-pointer"
                >
                  <div className="w-9 h-9 rounded-lg bg-[#E5B834]/10 border border-[#E5B834]/25 flex items-center justify-center text-[#F6D061] mb-3 group-hover:scale-105 transition-transform">
                    <IconComp className="w-4 h-4" />
                  </div>
                  <div className="text-[10px] uppercase text-[#F6D061] font-semibold tracking-wider mb-1">
                    {v.tag}
                  </div>
                  <h4 className="heading-font text-sm font-bold text-white group-hover:text-[#F6D061] transition-colors mb-1.5">
                    {v.name}
                  </h4>
                  <p className="text-gray-400 text-xs line-clamp-2 leading-relaxed">
                    {v.desc}
                  </p>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
