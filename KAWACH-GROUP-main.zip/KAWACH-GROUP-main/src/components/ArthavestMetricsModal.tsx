import React from 'react';
import { X, PieChart, ShieldCheck, CheckCircle2, TrendingUp, Coins, Activity } from 'lucide-react';

interface ArthavestMetricsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ArthavestMetricsModal: React.FC<ArthavestMetricsModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const holdings = [
    { sector: 'NEPSE Commercial Banking', weight: '28%', status: 'Core Allocation' },
    { sector: 'Hydropower & Green Energy', weight: '26%', status: 'High Growth' },
    { sector: 'Gold Hedge (XAU/USD)', weight: '15%', status: 'Counter-Cyclical' },
    { sector: 'Microfinance & Insurance', weight: '12%', status: 'Yield Accrual' },
    { sector: 'FinTech Tech Stack', weight: '10%', status: 'Proprietary IP' },
    { sector: 'Cash & Short-Term Money Market', weight: '9%', status: 'Liquid Buffer' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="glass-card max-w-2xl w-full p-6 sm:p-8 rounded-3xl relative border border-[#E5B834]/35 shadow-2xl max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-gray-400 hover:text-white text-xl p-1 rounded-lg hover:bg-white/10 transition-colors"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-4 mb-6">
          <div className="w-12 h-12 rounded-xl bg-[#E5B834]/15 border border-[#E5B834]/30 flex items-center justify-center text-[#F6D061] text-2xl shrink-0">
            <PieChart className="w-6 h-6 stroke-[2]" />
          </div>
          <div>
            <h3 className="heading-font text-2xl font-bold text-white">
              Arthavest Investment Co. Pvt. Ltd.
            </h3>
            <p className="text-xs text-[#F6D061] uppercase font-bold tracking-widest mt-0.5">
              Live Portfolio Strategy & Risk Architecture
            </p>
          </div>
        </div>

        {/* Core Institutional Stats */}
        <div className="grid sm:grid-cols-2 gap-3 mb-6">
          <div className="p-4 rounded-xl bg-[#02050d] border border-[#E5B834]/20">
            <div className="text-xs text-gray-400">Core Market Focus</div>
            <div className="text-white font-bold text-sm mt-1 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-[#F6D061]" />
              <span>NEPSE Equities & XAU/USD</span>
            </div>
          </div>
          <div className="p-4 rounded-xl bg-[#02050d] border border-[#E5B834]/20">
            <div className="text-xs text-gray-400">Quantitative Framework</div>
            <div className="text-white font-bold text-sm mt-1 flex items-center gap-2">
              <Activity className="w-4 h-4 text-[#F6D061]" />
              <span>Monte Carlo & VaR Screening</span>
            </div>
          </div>
          <div className="p-4 rounded-xl bg-[#02050d] border border-[#E5B834]/20">
            <div className="text-xs text-gray-400">Governance</div>
            <div className="text-white font-bold text-sm mt-1 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#F6D061]" />
              <span>10 Founding Shareholders</span>
            </div>
          </div>
          <div className="p-4 rounded-xl bg-[#02050d] border border-[#E5B834]/20">
            <div className="text-xs text-gray-400">Registration</div>
            <div className="text-white font-bold text-sm mt-1 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#F6D061]" />
              <span>OCR Nepal Reg. (Falgun 2082)</span>
            </div>
          </div>
        </div>

        {/* Sector Allocation Breakdown */}
        <div className="mb-6">
          <h4 className="text-xs uppercase font-bold text-gray-300 tracking-wider mb-3">
            Portfolio Sector Weightings
          </h4>
          <div className="space-y-2">
            {holdings.map((h, i) => (
              <div
                key={i}
                className="flex items-center justify-between p-2.5 rounded-lg bg-[#02050d]/80 border border-white/5 text-xs"
              >
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#E5B834]" />
                  <span className="text-white font-medium">{h.sector}</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-gray-400 text-[11px]">{h.status}</span>
                  <span className="text-[#F6D061] font-bold mono-font">{h.weight}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quantitative Limits */}
        <div className="p-4 rounded-xl bg-[#02050d] border border-white/10 mb-6 text-xs text-gray-300 space-y-1.5">
          <div className="font-semibold text-white">Automated Risk Safeguards:</div>
          <p className="text-gray-400">
            • 99% Confidence 1-Day Parametric VaR strictly capped at 1.8% of net asset value.
          </p>
          <p className="text-gray-400">
            • Maximum drawdown circuit breaker enforced with automatic cash preservation rebalancing.
          </p>
        </div>

        <button
          onClick={onClose}
          className="w-full py-3.5 rounded-xl text-xs font-bold uppercase tracking-wider text-[#02050d] bg-gradient-to-r from-[#F6D061] to-[#E5B834] hover:from-[#FBE288] hover:to-[#E5B834] transition-all cursor-pointer"
        >
          Close Snapshot
        </button>
      </div>
    </div>
  );
};
