import React, { useEffect, useRef, useState } from 'react';
import {
  Chart,
  LineController,
  LineElement,
  PointElement,
  LinearScale,
  CategoryScale,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js';
import { Download, Calculator, TrendingUp, ShieldCheck, CheckCircle2 } from 'lucide-react';

Chart.register(
  LineController,
  LineElement,
  PointElement,
  LinearScale,
  CategoryScale,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface InvestorSectionProps {
  onOpenReportModal: () => void;
  onOpenPortalModal: () => void;
}

export const InvestorSection: React.FC<InvestorSectionProps> = ({
  onOpenReportModal,
  onOpenPortalModal,
}) => {
  const chartCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const chartInstanceRef = useRef<Chart | null>(null);

  // Return Simulator State
  const [investmentAmount, setInvestmentAmount] = useState<number>(2000000); // 2,000,000 NPR
  const [projectedYears, setProjectedYears] = useState<number>(3);
  const [growthScenario, setGrowthScenario] = useState<'conservative' | 'target' | 'high'>('target');

  const scenarioRates = {
    conservative: { annualRate: 0.16, dividendYield: 0.06 },
    target: { annualRate: 0.24, dividendYield: 0.085 },
    high: { annualRate: 0.35, dividendYield: 0.11 },
  };

  const selectedRate = scenarioRates[growthScenario];
  const projectedValue = Math.round(
    investmentAmount * Math.pow(1 + selectedRate.annualRate, projectedYears)
  );
  const estimatedAnnualDividend = Math.round(investmentAmount * selectedRate.dividendYield);

  useEffect(() => {
    if (!chartCanvasRef.current) return;

    if (chartInstanceRef.current) {
      chartInstanceRef.current.destroy();
    }

    const ctx = chartCanvasRef.current.getContext('2d');
    if (!ctx) return;

    chartInstanceRef.current = new Chart(ctx, {
      type: 'line',
      data: {
        labels: [
          'Q1 2025',
          'Q2 2025',
          'Q3 2025',
          'Q4 2025',
          'Q1 2026',
          'Q2 2026',
          'Q3 2026',
          'Q4 2026 (Est)',
        ],
        datasets: [
          {
            label: 'Arthavest Investment Co. ($M AUM)',
            data: [10, 15, 22, 28, 38, 45, 58, 70],
            borderColor: '#E5B834',
            backgroundColor: 'rgba(229, 184, 52, 0.12)',
            fill: true,
            tension: 0.35,
            pointBackgroundColor: '#E5B834',
            pointRadius: 4,
          },
          {
            label: 'Kawach RWA ($KWC TVL)',
            data: [0, 2, 5, 12, 18, 25, 34, 48],
            borderColor: '#A855F7',
            backgroundColor: 'rgba(168, 85, 247, 0.06)',
            fill: true,
            tension: 0.35,
            pointBackgroundColor: '#A855F7',
            pointRadius: 4,
          },
          {
            label: 'FMCG & Industrial Operations ($M)',
            data: [0, 0, 1, 4, 10, 16, 24, 35],
            borderColor: '#F59E0B',
            backgroundColor: 'transparent',
            borderDash: [5, 5],
            tension: 0.35,
            pointBackgroundColor: '#F59E0B',
            pointRadius: 3,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
          mode: 'index',
          intersect: false,
        },
        plugins: {
          legend: {
            position: 'top',
            labels: {
              color: '#d1d5db',
              font: {
                family: 'Plus Jakarta Sans',
                size: 11,
                weight: 500,
              },
              boxWidth: 14,
              padding: 16,
            },
          },
          tooltip: {
            backgroundColor: '#050a17',
            borderColor: 'rgba(229, 184, 52, 0.3)',
            borderWidth: 1,
            titleFont: { family: 'Plus Jakarta Sans', size: 12, weight: 'bold' },
            bodyFont: { family: 'Plus Jakarta Sans', size: 11 },
            padding: 10,
          },
        },
        scales: {
          x: {
            grid: {
              color: 'rgba(255, 255, 255, 0.05)',
            },
            ticks: {
              color: '#9ca3af',
              font: { family: 'Plus Jakarta Sans', size: 10 },
            },
          },
          y: {
            grid: {
              color: 'rgba(255, 255, 255, 0.05)',
            },
            ticks: {
              color: '#9ca3af',
              font: { family: 'Plus Jakarta Sans', size: 10 },
              callback: function (value) {
                return '$' + value + 'M';
              },
            },
          },
        },
      },
    });

    return () => {
      if (chartInstanceRef.current) {
        chartInstanceRef.current.destroy();
      }
    };
  }, []);

  return (
    <section id="sec-investor" className="py-20 bg-[#050a17]/50 border-t border-[#E5B834]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="text-xs uppercase tracking-[0.25em] text-[#F6D061] font-semibold mb-3">
            Capital & Performance
          </div>
          <h2 className="heading-font text-3xl sm:text-5xl font-bold text-white mb-6">
            Investor Relations & Metrics
          </h2>
          <p className="text-gray-300 font-light text-base leading-relaxed">
            KAWACH GROUP maintains absolute transparent capital governance for our partners, syndicated shareholders, and institutional stakeholders.
          </p>
        </div>

        {/* Metrics & Chart Grid */}
        <div className="grid lg:grid-cols-3 gap-8 mb-14">
          {/* Chart Widget */}
          <div className="lg:col-span-2 glass-card p-6 sm:p-8 rounded-3xl flex flex-col justify-between">
            <div>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
                <div>
                  <h3 className="heading-font text-xl font-bold text-white">
                    Group Consolidated Growth Simulation
                  </h3>
                  <p className="text-xs text-gray-400 mt-1">
                    Quarterly Asset Allocations across Equity, RWA & Industrial Ops
                  </p>
                </div>
                <span className="text-xs font-semibold text-[#F6D061] bg-[#E5B834]/10 px-3 py-1 rounded-full border border-[#E5B834]/25 self-start sm:self-auto">
                  AUM Projection
                </span>
              </div>
              <div className="h-72 sm:h-80 w-full relative">
                <canvas ref={chartCanvasRef} id="investorChart" />
              </div>
            </div>

            <div className="pt-4 border-t border-white/5 flex flex-wrap items-center justify-between text-xs text-gray-400 gap-4 mt-4">
              <span>Audited under Nepal Accounting Standards (NAS)</span>
              <span className="mono-font text-[#F6D061]">Target AUM: $153M+ (Consolidated 2026)</span>
            </div>
          </div>

          {/* Capital Allocation Breakdown */}
          <div className="glass-card p-6 sm:p-8 rounded-3xl flex flex-col justify-between">
            <div>
              <h3 className="heading-font text-xl font-bold text-white mb-6">
                Capital Allocation Strategy
              </h3>

              <div className="space-y-6">
                <div>
                  <div className="flex justify-between text-xs font-bold mb-2">
                    <span className="text-gray-300">Public Equity & Equities (Arthavest)</span>
                    <span className="text-[#F6D061] mono-font tabular-nums">45%</span>
                  </div>
                  <div className="w-full h-2.5 rounded-full bg-[#02050d] overflow-hidden border border-white/5">
                    <div className="h-full bg-gradient-to-r from-[#F6D061] to-[#E5B834] rounded-full" style={{ width: '45%' }} />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs font-bold mb-2">
                    <span className="text-gray-300">RWA Smart Contract & Real Estate</span>
                    <span className="text-purple-400 mono-font tabular-nums">25%</span>
                  </div>
                  <div className="w-full h-2.5 rounded-full bg-[#02050d] overflow-hidden border border-white/5">
                    <div className="h-full bg-purple-500 rounded-full" style={{ width: '25%' }} />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs font-bold mb-2">
                    <span className="text-gray-300">FMCG & Industrial Operations</span>
                    <span className="text-amber-400 mono-font tabular-nums">20%</span>
                  </div>
                  <div className="w-full h-2.5 rounded-full bg-[#02050d] overflow-hidden border border-white/5">
                    <div className="h-full bg-amber-500 rounded-full" style={{ width: '20%' }} />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs font-bold mb-2">
                    <span className="text-gray-300">Liquid Cash & Commodities Reserves</span>
                    <span className="text-emerald-400 mono-font tabular-nums">10%</span>
                  </div>
                  <div className="w-full h-2.5 rounded-full bg-[#02050d] overflow-hidden border border-white/5">
                    <div className="h-full bg-emerald-500 rounded-full" style={{ width: '10%' }} />
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-3 mt-8">
              <button
                onClick={onOpenReportModal}
                className="w-full py-3.5 rounded-xl text-xs font-bold uppercase tracking-wider text-[#02050d] bg-gradient-to-r from-[#F6D061] via-[#E5B834] to-[#C89B1D] hover:shadow-md hover:shadow-[#E5B834]/25 transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
              >
                <Download className="w-4 h-4 stroke-[2.4]" />
                <span>Download Shareholder Report</span>
              </button>
              <button
                onClick={onOpenPortalModal}
                className="w-full py-2.5 rounded-xl text-xs font-semibold text-gray-300 border border-white/10 hover:border-[#E5B834]/40 hover:text-white transition-colors"
              >
                Access Partner Ledger
              </button>
            </div>
          </div>
        </div>

        {/* Shareholder Return Simulation Calculator */}
        <div className="glass-card p-8 rounded-3xl border border-[#E5B834]/25">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-[#E5B834]/15 flex items-center justify-center text-[#F6D061]">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <h3 className="heading-font text-xl font-bold text-white">
                Syndicate Return & Dividend Simulator
              </h3>
              <p className="text-xs text-gray-400">
                Model capital compounding and expected quarterly dividend accrual under Kawach Group charter.
              </p>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="space-y-5">
              <div>
                <label className="block text-xs uppercase font-bold text-gray-400 mb-2">
                  Capital Commitment: NPR {investmentAmount.toLocaleString()}
                </label>
                <input
                  type="range"
                  min={500000}
                  max={20000000}
                  step={250000}
                  value={investmentAmount}
                  onChange={(e) => setInvestmentAmount(Number(e.target.value))}
                  className="w-full accent-[#E5B834] cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-gray-500 mt-1">
                  <span>500K</span>
                  <span>5M</span>
                  <span>10M</span>
                  <span>20M+</span>
                </div>
              </div>

              <div>
                <label className="block text-xs uppercase font-bold text-gray-400 mb-2">
                  Holding Horizon: {projectedYears} {projectedYears === 1 ? 'Year' : 'Years'}
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {[1, 2, 3, 5].map((yr) => (
                    <button
                      key={yr}
                      onClick={() => setProjectedYears(yr)}
                      className={`py-2 rounded-lg text-xs font-bold transition-colors ${
                        projectedYears === yr
                          ? 'bg-[#E5B834] text-[#02050d]'
                          : 'bg-[#02050d] text-gray-400 hover:text-white border border-white/10'
                      }`}
                    >
                      {yr}Y
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs uppercase font-bold text-gray-400 mb-2">
                  Strategy Scenario
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['conservative', 'target', 'high'] as const).map((sc) => (
                    <button
                      key={sc}
                      onClick={() => setGrowthScenario(sc)}
                      className={`py-2 rounded-lg text-xs font-bold capitalize transition-colors ${
                        growthScenario === sc
                          ? 'bg-[#E5B834]/20 border border-[#E5B834] text-[#F6D061]'
                          : 'bg-[#02050d] text-gray-400 hover:text-white border border-white/10'
                      }`}
                    >
                      {sc}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Results Display */}
            <div className="md:col-span-2 grid sm:grid-cols-2 gap-4 bg-[#02050d]/80 p-6 rounded-2xl border border-white/10">
              <div className="p-4 rounded-xl bg-white/[0.03]">
                <div className="text-xs text-gray-400 mb-1">Projected Total Portfolio Value</div>
                <div className="heading-font text-2xl lg:text-3xl font-black text-[#F6D061] mono-font tabular-nums">
                  NPR {projectedValue.toLocaleString()}
                </div>
                <p className="text-[11px] text-emerald-400 mt-1 flex items-center gap-1">
                  <TrendingUp className="w-3 h-3" />
                  <span>+{Math.round(((projectedValue - investmentAmount) / investmentAmount) * 100)}% Cumulative Gain</span>
                </p>
              </div>

              <div className="p-4 rounded-xl bg-white/[0.03]">
                <div className="text-xs text-gray-400 mb-1">Estimated Annual Dividends</div>
                <div className="heading-font text-2xl lg:text-3xl font-black text-white mono-font tabular-nums">
                  NPR {estimatedAnnualDividend.toLocaleString()}
                </div>
                <p className="text-[11px] text-gray-400 mt-1">
                  Approx. NPR {Math.round(estimatedAnnualDividend / 4).toLocaleString()} / quarter
                </p>
              </div>

              <div className="sm:col-span-2 pt-2 text-xs text-gray-400 border-t border-white/5 space-y-1">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#E5B834]" />
                  <span>Capital principal insured via counter-cyclical gold commodities allocation</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#E5B834]" />
                  <span>Full partner quorum voting power attached to equity stakes exceeding 5%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
