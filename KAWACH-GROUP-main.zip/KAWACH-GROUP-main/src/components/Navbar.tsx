import React, { useState } from 'react';
import { Shield, Menu, X, LogIn } from 'lucide-react';

interface NavbarProps {
  currentSection: string;
  onNavigate: (sectionId: string) => void;
  onOpenPortal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentSection,
  onNavigate,
  onOpenPortal,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'Corporate Overview' },
    { id: 'portfolio', label: 'Group Subsidiaries' },
    { id: 'investor', label: 'Investor Relations' },
    { id: 'contact', label: 'Contact' },
  ];

  const handleNavClick = (id: string) => {
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  return (
    <nav
      className="fixed top-0 left-0 w-full z-50 transition-all duration-300 bg-[#02050d]/85 backdrop-blur-md border-b border-[#E5B834]/15"
      id="navbar"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20 gap-8">
          {/* Zone 1: Brand Wordmark */}
          <button
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-3 text-left shrink-0 group focus:outline-none focus-visible:ring-2 focus-visible:ring-[#E5B834]"
          >
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#F6D061] to-[#9E7711] flex items-center justify-center shadow-lg shadow-[#E5B834]/20 group-hover:scale-105 transition-transform">
              <Shield className="w-5 h-5 text-[#02050d] stroke-[2.4]" />
            </div>
            <div>
              <span className="heading-font text-2xl font-black tracking-wider text-white block leading-none">
                KAWACH
              </span>
              <span className="block text-[9px] uppercase tracking-[0.28em] text-[#F6D061] font-semibold mt-1">
                Group Enterprise
              </span>
            </div>
          </button>

          {/* Zone 2: Navigation Links */}
          <div className="hidden md:flex items-center space-x-7 text-sm font-medium">
            {navItems.map((item) => {
              const isActive = currentSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`py-2 transition-colors whitespace-nowrap shrink-0 relative focus:outline-none focus-visible:ring-1 focus-visible:ring-[#E5B834] ${
                    isActive
                      ? 'text-[#F6D061] font-semibold'
                      : 'text-gray-300 hover:text-[#F6D061]'
                  }`}
                >
                  {item.label}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-[#E5B834] to-transparent rounded-full" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Zone 3: Primary Action */}
          <div className="hidden lg:flex items-center gap-4 shrink-0">
            <button
              onClick={onOpenPortal}
              className="px-5 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider text-[#02050d] bg-gradient-to-r from-[#F6D061] via-[#E5B834] to-[#C89B1D] hover:from-[#FBE288] hover:to-[#E5B834] transition-all shadow-md shadow-[#E5B834]/20 active:scale-95 flex items-center gap-2 cursor-pointer"
            >
              <span>Partner Portal</span>
              <LogIn className="w-3.5 h-3.5 stroke-[2.4]" />
            </button>
          </div>

          {/* Mobile hamburger button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-gray-300 hover:text-[#F6D061] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#E5B834] rounded-lg"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#050a17]/95 backdrop-blur-xl border-b border-[#E5B834]/20 px-4 pt-3 pb-6 space-y-2 animate-in fade-in slide-in-from-top-2 duration-200">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`block w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                currentSection === item.id
                  ? 'bg-[#E5B834]/15 text-[#F6D061] font-semibold'
                  : 'text-gray-300 hover:text-white hover:bg-white/5'
              }`}
            >
              {item.label}
            </button>
          ))}
          <button
            onClick={() => {
              setMobileMenuOpen(false);
              onOpenPortal();
            }}
            className="w-full mt-3 px-4 py-3 rounded-lg text-xs font-bold uppercase tracking-wider text-[#02050d] bg-gradient-to-r from-[#F6D061] to-[#E5B834] flex items-center justify-center gap-2"
          >
            <span>Partner Portal Access</span>
            <LogIn className="w-4 h-4" />
          </button>
        </div>
      )}
    </nav>
  );
};
