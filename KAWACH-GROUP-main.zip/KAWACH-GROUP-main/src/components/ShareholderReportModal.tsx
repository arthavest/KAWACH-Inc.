import React from 'react';
import { X, Printer, Shield, Download, CheckCircle2, FileText } from 'lucide-react';

interface ShareholderReportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ShareholderReportModal: React.FC<ShareholderReportModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="glass-card max-w-2xl w-full p-6 sm:p-8 rounded-3xl relative border border-[#E5B834]/35 shadow-2xl max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-gray-400 hover:text-white text-xl p-1 rounded-lg hover:bg-white/10 transition-colors"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6 pb-4 border-b border-white/10">
          <div className="w-10 h-10 rounded-xl bg-[#E5B834]/15 border border-[#E5B834]/30 flex items-center justify-center text-[#F6D061]">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <h3 className="heading-font text-2xl font-bold text-white">
              KAWACH Group Executive Dossier
            </h3>
            <p className="text-xs text-[#F6D061] uppercase tracking-widest font-semibold">
              Consolidated Shareholder & Capital Report · FY2082/83
            </p>
          </div>
        </div>

        <div className="space-y-5 text-xs text-gray-300">
          {/* Executive Summary */}
          <div className="p-4 rounded-xl bg-[#02050d] border border-white/10 space-y-2">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider">
              1. Executive Statement of Entity
            </h4>
            <p className="leading-relaxed text-gray-400">
              KAWACH Group is incorporated under the Office of the Company Registrar, Government of Nepal (Falgun 2082), serving as the apex governance holding entity across capital market asset management, real-world asset tokenization, industrial FMCG processing, and algorithmic market intelligence.
            </p>
          </div>

          {/* Subsidiary Performance Matrix */}
          <div className="p-4 rounded-xl bg-[#02050d] border border-white/10 space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider">
              2. Subsidiary Holdings & Capital Status
            </h4>
            <div className="space-y-2">
              <div className="flex justify-between border-b border-white/5 pb-1.5">
                <span className="font-semibold text-white">Arthavest Investment Co. Pvt. Ltd.</span>
                <span className="text-emerald-400 font-bold">Operational (45% Allocation)</span>
              </div>
              <div className="flex justify-between border-b border-white/5 pb-1.5">
                <span className="font-semibold text-white">Kawach ($KWC) RWA Smart Contracts</span>
                <span className="text-purple-400 font-bold">Architecture Phase (25%)</span>
              </div>
              <div className="flex justify-between border-b border-white/5 pb-1.5">
                <span className="font-semibold text-white">Kawach Foods & FMCG Manufacturing</span>
                <span className="text-amber-400 font-bold">Setup Phase (20%)</span>
              </div>
              <div className="flex justify-between">
                <span className="font-semibold text-white">Arthavest Tech & P2P Engine</span>
                <span className="text-blue-400 font-bold">R&D Core (Internal Tech)</span>
              </div>
            </div>
          </div>

          {/* Fiduciary Verification & Sign-off */}
          <div className="p-4 rounded-xl bg-[#02050d] border border-white/10 space-y-2">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider">
              3. Fiduciary Attestation
            </h4>
            <p className="text-gray-400 leading-relaxed">
              All books, shareholder allocations, and capital movements are reconciled in compliance with standard corporate laws of Nepal and audited by chartered accountants.
            </p>
            <div className="pt-2 text-[11px] text-[#F6D061] flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Certified by Executive Chair Mahendra Dahal & Founding Quorum</span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-3 mt-6 pt-4 border-t border-white/10">
          <button
            onClick={handlePrint}
            className="flex-1 py-3 rounded-xl text-xs font-bold uppercase tracking-wider text-[#02050d] bg-gradient-to-r from-[#F6D061] to-[#E5B834] hover:shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>Print / Save PDF</span>
          </button>
          <button
            onClick={onClose}
            className="px-6 py-3 rounded-xl text-xs font-semibold text-gray-300 border border-white/15 hover:bg-white/10 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
