import React, { useState } from 'react';
import { MapPin, Mail, Building, Send, CheckCircle2, ShieldAlert } from 'lucide-react';
import confetti from 'canvas-confetti';

export const ContactSection: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    vertical: 'KAWACH Parent Group Holdings',
    message: '',
  });

  const [submitted, setSubmitted] = useState(false);
  const [ticketId, setTicketId] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) return;

    const randomId = `KW-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    setTicketId(randomId);
    setSubmitted(true);

    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.8 },
        colors: ['#E5B834', '#F6D061', '#ffffff'],
      });
    } catch {
      // ignore
    }
  };

  const handleReset = () => {
    setSubmitted(false);
    setFormData({
      name: '',
      email: '',
      phone: '',
      vertical: 'KAWACH Parent Group Holdings',
      message: '',
    });
  };

  return (
    <section id="sec-contact" className="py-20 border-t border-[#E5B834]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Contact Details & Headquarters */}
          <div>
            <div className="text-xs uppercase tracking-[0.25em] text-[#F6D061] font-semibold mb-3">
              Corporate Headquarters
            </div>
            <h2 className="heading-font text-3xl sm:text-5xl font-bold text-white mb-6">
              Connect With KAWACH GROUP
            </h2>
            <p className="text-gray-300 font-light text-base mb-10 leading-relaxed">
              For corporate partnerships, institutional investments, subsidiary inquiries, syndicate capital participation, or joint ventures, reach out to our executive headquarters.
            </p>

            <div className="space-y-6">
              <div className="flex items-start gap-4 glass-card p-5 rounded-2xl">
                <div className="w-12 h-12 rounded-xl bg-[#E5B834]/10 border border-[#E5B834]/25 flex items-center justify-center text-[#F6D061] text-lg shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white mb-1">
                    Corporate Office Location
                  </h4>
                  <p className="text-gray-300 text-xs leading-relaxed">
                    Ward 8, Kathmandu Metropolitan City, Bagmati Province, Nepal
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4 glass-card p-5 rounded-2xl">
                <div className="w-12 h-12 rounded-xl bg-[#E5B834]/10 border border-[#E5B834]/25 flex items-center justify-center text-[#F6D061] text-lg shrink-0">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white mb-1">
                    Executive Communications
                  </h4>
                  <p className="text-gray-300 text-xs mono-font">
                    contact@kawachgroup.com · corporate@arthavest.com
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4 glass-card p-5 rounded-2xl">
                <div className="w-12 h-12 rounded-xl bg-[#E5B834]/10 border border-[#E5B834]/25 flex items-center justify-center text-[#F6D061] text-lg shrink-0">
                  <Building className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white mb-1">
                    Company Registration & Filing
                  </h4>
                  <p className="text-gray-300 text-xs leading-relaxed">
                    Office of the Company Registrar, Ministry of Industry, Commerce & Supplies, Government of Nepal (Reg. Falgun 2082)
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Inquiry Form */}
          <div className="glass-card p-8 sm:p-10 rounded-3xl border border-[#E5B834]/25">
            {submitted ? (
              <div className="py-10 text-center space-y-4 animate-in fade-in duration-300">
                <div className="w-16 h-16 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto mb-2">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 className="heading-font text-2xl font-bold text-white">
                  Formal Inquiry Dispatched
                </h3>
                <p className="text-sm text-gray-300 max-w-sm mx-auto leading-relaxed">
                  Thank you for connecting with KAWACH GROUP. Your strategic docket has been logged with Executive Management.
                </p>
                <div className="p-4 rounded-xl bg-[#02050d] border border-white/10 text-xs text-left max-w-sm mx-auto space-y-1.5 mono-font">
                  <div className="flex justify-between">
                    <span className="text-gray-500">Reference Docket:</span>
                    <span className="text-[#F6D061] font-bold">{ticketId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Addressed Vertical:</span>
                    <span className="text-white">{formData.vertical}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Contact:</span>
                    <span className="text-white">{formData.email}</span>
                  </div>
                </div>
                <button
                  onClick={handleReset}
                  className="px-6 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold text-white transition-colors"
                >
                  Submit Another Inquiry
                </button>
              </div>
            ) : (
              <div>
                <h3 className="heading-font text-2xl font-bold text-white mb-2">
                  Send Partnership Inquiry
                </h3>
                <p className="text-xs text-gray-400 mb-6">
                  Direct strategic routing to Managing Director Mahendra Dahal and Executive Board.
                </p>

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs uppercase text-gray-400 font-bold mb-1.5">
                      Full Legal Name
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-[#02050d] border border-[#E5B834]/20 text-white placeholder-gray-500 focus:outline-none focus:border-[#E5B834] text-sm transition-colors"
                      placeholder="e.g. Executive Partner"
                    />
                  </div>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs uppercase text-gray-400 font-bold mb-1.5">
                        Corporate Email
                      </label>
                      <input
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl bg-[#02050d] border border-[#E5B834]/20 text-white placeholder-gray-500 focus:outline-none focus:border-[#E5B834] text-sm transition-colors"
                        placeholder="partner@institution.com"
                      />
                    </div>
                    <div>
                      <label className="block text-xs uppercase text-gray-400 font-bold mb-1.5">
                        Phone / WhatsApp
                      </label>
                      <input
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl bg-[#02050d] border border-[#E5B834]/20 text-white placeholder-gray-500 focus:outline-none focus:border-[#E5B834] text-sm transition-colors"
                        placeholder="+977 98XXXXXXXX"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs uppercase text-gray-400 font-bold mb-1.5">
                      Subsidiary / Vertical of Interest
                    </label>
                    <select
                      value={formData.vertical}
                      onChange={(e) => setFormData({ ...formData, vertical: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-[#02050d] border border-[#E5B834]/20 text-white focus:outline-none focus:border-[#E5B834] text-sm transition-colors"
                    >
                      <option>KAWACH Parent Group Holdings</option>
                      <option>Arthavest Investment Company</option>
                      <option>Kawach ($KWC) RWA Smart Contract</option>
                      <option>FMCG & Spice Manufacturing Venture</option>
                      <option>Arthavest P2P & FinTech Engine</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs uppercase text-gray-400 font-bold mb-1.5">
                      Strategic Message / Capital Proposal
                    </label>
                    <textarea
                      rows={4}
                      required
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-[#02050d] border border-[#E5B834]/20 text-white placeholder-gray-500 focus:outline-none focus:border-[#E5B834] text-sm transition-colors"
                      placeholder="Describe your corporate inquiry, syndicate allocation, or strategic proposal..."
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-4 rounded-xl text-xs font-bold uppercase tracking-wider text-[#02050d] bg-gradient-to-r from-[#F6D061] via-[#E5B834] to-[#C89B1D] hover:shadow-lg hover:shadow-[#E5B834]/25 transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
                  >
                    <span>Submit Formal Inquiry</span>
                    <Send className="w-4 h-4 stroke-[2.4]" />
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
