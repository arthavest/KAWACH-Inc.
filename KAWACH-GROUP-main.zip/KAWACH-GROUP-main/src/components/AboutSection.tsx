import React from 'react';
import { Eye, Layers, ShieldCheck, UserCheck, CheckCircle2, FileText, Scale, Landmark } from 'lucide-react';

export const AboutSection: React.FC = () => {
  const pillars = [
    {
      icon: Eye,
      title: 'Apex Governance',
      desc: 'Ensuring robust capital allocation, risk modeling, and institutional compliance across all subsidiary verticals to maximize long-term shareholder equity.',
      points: ['Multi-stakeholder voting quorum', 'Independent fiduciary oversight', 'Quarterly capital audit cadence'],
    },
    {
      icon: Layers,
      title: 'Diversified Synergy',
      desc: 'Combining public market asset management, real-world asset tokenization, consumer goods manufacturing, and tech innovation into a resilient ecosystem.',
      points: ['Cross-vertical liquidity buffers', 'Counter-cyclical asset distribution', 'Integrated internal market tech'],
    },
    {
      icon: ShieldCheck,
      title: 'Zero-Knowledge Security',
      desc: 'Deploying advanced risk mitigation algorithms, smart contract architecture, and algorithmic hedging to safeguard multi-vertical holdings.',
      points: ['Multi-signature vault protocol', 'Monte Carlo VaR threshold guards', 'Zero-knowledge access recovery'],
    },
  ];

  const legalSpecs = [
    {
      title: 'Corporate Charter & Registration',
      subtitle: 'Office of the Company Registrar, Nepal',
      detail: 'Formally incorporated in Falgun 2082 under the Companies Act of Nepal, with full authorized institutional charter.',
      icon: Landmark,
    },
    {
      title: '10-Partner Quorum Governance',
      subtitle: 'Structured Capital Syndicate',
      detail: 'Institutional syndicate agreement governing multi-partner capital contributions, voting supermajorities, and dispute mediation.',
      icon: Scale,
    },
    {
      title: 'Fiduciary Risk Architecture',
      subtitle: 'Quantitative Safeguards',
      detail: 'Algorithmic value-at-risk ceilings, automated broker-level stop mechanisms, and multi-signature treasury disbursement.',
      icon: FileText,
    },
  ];

  return (
    <section id="sec-about" className="py-20 bg-[#050a17]/60 border-t border-[#E5B834]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="text-xs uppercase tracking-[0.25em] text-[#F6D061] font-semibold mb-3">
            Corporate Architecture
          </div>
          <h2 className="heading-font text-3xl sm:text-5xl font-bold text-white mb-6">
            The Institutional Shield
          </h2>
          <p className="text-gray-300 font-light text-base leading-relaxed">
            Modeled after premier global holding conglomerates, KAWACH operates as the central governance, strategic allocation, and risk-management umbrella overseeing autonomous operational entities.
          </p>
        </div>

        {/* Vision & Mission Grid */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {pillars.map((p, idx) => {
            const IconComp = p.icon;
            return (
              <div key={idx} className="glass-card p-8 rounded-2xl flex flex-col justify-between">
                <div>
                  <div className="w-12 h-12 rounded-xl bg-[#E5B834]/10 border border-[#E5B834]/30 flex items-center justify-center text-[#F6D061] text-xl mb-6">
                    <IconComp className="w-6 h-6 stroke-[2]" />
                  </div>
                  <h3 className="heading-font text-xl font-bold text-white mb-3">
                    {p.title}
                  </h3>
                  <p className="text-gray-300 text-sm leading-relaxed mb-6">
                    {p.desc}
                  </p>
                </div>
                <div className="space-y-2 pt-4 border-t border-white/5">
                  {p.points.map((pt, i) => (
                    <div key={i} className="flex items-center gap-2 text-xs text-gray-400">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#E5B834] shrink-0" />
                      <span>{pt}</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Group Leadership Message */}
        <div className="glass-card p-8 sm:p-12 rounded-3xl border border-[#E5B834]/25 bg-gradient-to-r from-[#050a17] via-[#0b1329] to-[#050a17] mb-16 shadow-xl">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="w-32 h-32 rounded-2xl bg-[#02050d] border-2 border-[#E5B834]/40 flex flex-col items-center justify-center p-4 text-center shrink-0 shadow-lg shadow-[#E5B834]/10">
              <div className="w-14 h-14 rounded-full bg-[#E5B834]/15 border border-[#E5B834]/30 flex items-center justify-center text-[#F6D061] mb-2">
                <UserCheck className="w-7 h-7" />
              </div>
              <span className="text-[10px] uppercase font-bold text-[#F6D061] tracking-wider">
                Executive Chair
              </span>
            </div>
            <div className="text-center md:text-left">
              <h3 className="heading-font text-2xl sm:text-3xl font-bold text-white mb-1.5">
                Mahendra Dahal
              </h3>
              <p className="text-[#F6D061] text-xs font-semibold uppercase tracking-widest mb-4">
                Founder & Managing Director | KAWACH Group
              </p>
              <blockquote className="text-gray-300 text-sm sm:text-base italic leading-relaxed relative pl-4 border-l-2 border-[#E5B834]/60">
                &ldquo;Our mission with KAWACH is to build an unshakeable institutional foundation—a fortress of capital efficiency, technological dominance, and operational excellence capable of scaling across domestic and international markets.&rdquo;
              </blockquote>
            </div>
          </div>
        </div>

        {/* Institutional Charter & Legal Safeguards */}
        <div className="grid md:grid-cols-3 gap-6">
          {legalSpecs.map((spec, index) => {
            const Icon = spec.icon;
            return (
              <div key={index} className="glass-card-subtle p-6 rounded-2xl border border-white/10 hover:border-[#E5B834]/30 transition-all">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-9 h-9 rounded-lg bg-[#E5B834]/10 flex items-center justify-center text-[#F6D061]">
                    <Icon className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="heading-font text-sm font-bold text-white">
                      {spec.title}
                    </h4>
                    <p className="text-[10px] uppercase text-[#F6D061] tracking-wider">
                      {spec.subtitle}
                    </p>
                  </div>
                </div>
                <p className="text-gray-400 text-xs leading-relaxed">
                  {spec.detail}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
