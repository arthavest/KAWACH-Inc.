import React from 'react';
import { Shield, Globe, Github, Linkedin, ArrowUp } from 'lucide-react';

interface FooterProps {
  onNavigate: (sectionId: string) => void;
  onSelectSubsidiary: (subId: string) => void;
  onOpenPortal: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onNavigate,
  onSelectSubsidiary,
  onOpenPortal,
}) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="border-t border-[#E5B834]/15 bg-[#02050d] py-16 text-sm text-gray-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 mb-14">
          {/* Brand Col */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#F6D061] to-[#C89B1D] flex items-center justify-center text-[#02050d] font-bold shadow-md shadow-[#E5B834]/20">
                <Shield className="w-4 h-4 text-[#02050d] stroke-[2.5]" />
              </div>
              <span className="heading-font text-xl font-bold text-white tracking-wider">
                KAWACH GROUP
              </span>
            </div>
            <p className="text-xs text-gray-400 leading-relaxed max-w-sm mb-6">
              KAWACH Group is a premier institutional parent conglomerate orchestrating financial asset management, real-world asset tokenization, industrial manufacturing, and market quantitative systems.
            </p>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-white/5 border border-white/10 text-[11px] text-[#F6D061] mono-font">
              <span>OCR Nepal Reg: Falgun 2082</span>
              <span>·</span>
              <span>Bagmati Province</span>
            </div>
          </div>

          {/* Group Verticals */}
          <div>
            <h4 className="text-white text-xs uppercase tracking-widest font-bold mb-4">
              Group Verticals
            </h4>
            <ul className="space-y-2.5 text-xs">
              <li>
                <button
                  onClick={() => {
                    onSelectSubsidiary('arthavest');
                    onNavigate('portfolio');
                  }}
                  className="hover:text-[#F6D061] transition-colors text-left"
                >
                  Arthavest Investment Co.
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    onSelectSubsidiary('rwa');
                    onNavigate('portfolio');
                  }}
                  className="hover:text-[#F6D061] transition-colors text-left"
                >
                  Kawach RWA ($KWC)
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    onSelectSubsidiary('fmcg');
                    onNavigate('portfolio');
                  }}
                  className="hover:text-[#F6D061] transition-colors text-left"
                >
                  Kawach FMCG & Spices
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    onSelectSubsidiary('tech');
                    onNavigate('portfolio');
                  }}
                  className="hover:text-[#F6D061] transition-colors text-left"
                >
                  Arthavest Tech & P2P
                </button>
              </li>
            </ul>
          </div>

          {/* Governance & Links */}
          <div>
            <h4 className="text-white text-xs uppercase tracking-widest font-bold mb-4">
              Governance
            </h4>
            <ul className="space-y-2.5 text-xs">
              <li>
                <button
                  onClick={onOpenPortal}
                  className="hover:text-[#F6D061] transition-colors text-left font-medium text-gray-300"
                >
                  Partner Portal Login
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('investor')}
                  className="hover:text-[#F6D061] transition-colors text-left"
                >
                  Investor Relations & Metrics
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('about')}
                  className="hover:text-[#F6D061] transition-colors text-left"
                >
                  Executive Structure
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('contact')}
                  className="hover:text-[#F6D061] transition-colors text-left"
                >
                  Headquarters & Inquiries
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/5 pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-gray-400 gap-4">
          <p>© 2026 KAWACH GROUP. All rights reserved. Arthavest Investment Company Pvt. Ltd.</p>
          <div className="flex items-center space-x-6">
            <span className="text-gray-400 hover:text-[#F6D061] transition-colors cursor-pointer" title="LinkedIn">
              <Linkedin className="w-4 h-4" />
            </span>
            <span className="text-gray-400 hover:text-[#F6D061] transition-colors cursor-pointer" title="GitHub Core Repositories">
              <Github className="w-4 h-4" />
            </span>
            <span className="text-gray-400 hover:text-[#F6D061] transition-colors cursor-pointer" title="Global Infrastructure">
              <Globe className="w-4 h-4" />
            </span>
            <button
              onClick={scrollToTop}
              className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-gray-300 hover:text-[#F6D061] transition-colors ml-2"
              title="Return to top"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
